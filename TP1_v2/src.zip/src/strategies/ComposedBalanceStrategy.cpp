/*
 * ComposedBalanceStrategy.cpp
 *
 *  Created on: Apr 29, 2010
 *      Author: carlos
 */

#include "ComposedBalanceStrategy.h"

ComposedBalanceStrategy::ComposedBalanceStrategy() {
}

ComposedBalanceStrategy::~ComposedBalanceStrategy() {
}
