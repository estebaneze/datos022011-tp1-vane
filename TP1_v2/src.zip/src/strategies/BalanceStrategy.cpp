/*
 * BalaceStrategy.cpp
 *
 *  Created on: Apr 28, 2010
 *      Author: carlos
 */

#include "BalanceStrategy.h"
#include "../BPlusTree/Node.h"
#include "../BPlusTree/LeafNode.h"
BalanceStrategy::BalanceStrategy() {

}

BalanceStrategy::~BalanceStrategy() {
}
