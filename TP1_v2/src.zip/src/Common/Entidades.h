/*
 * Entidades.h
 *
 *  Created on: 09/10/2011
 *      Author: minnie
 */

#ifndef ENTIDADES_H_
#define ENTIDADES_H_

#include "../Entidades/Candidato.h"
#include "../Entidades/Cargo.h"
#include "../Entidades/Administrador.h"
#include "../Entidades/Conteo.h"
#include "../Entidades/Distrito.h"
#include "../Entidades/Eleccion.h"
#include "../Entidades/Lista.h"
#include "../Entidades/Votante.h"

#endif /* ENTIDADES_H_ */
