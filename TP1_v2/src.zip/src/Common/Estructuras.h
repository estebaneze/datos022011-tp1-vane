/*
 * Estructuras.h
 *
 *  Created on: 27/09/2011
 *      Author: minnie
 */

#ifndef ESTRUCTURAS_H_
#define ESTRUCTURAS_H_

#include "../Estructuras/HashExtensible.h"
#include "../Estructuras/bp_tree.h"
/*
#include "../Estructuras/base64.h"
#include "../Estructuras/bp_node.h"
#include "../Estructuras/bp_subnode.h"
#include "../Estructuras/Bucket.h"
#include "../Estructuras/Buckets.h"
#include "../Estructuras/Comparable.h"
#include "../Estructuras/ComuDatos.h"
#include "../Estructuras/Directory.h"
#include "../Estructuras/Field.h"
#include "../Estructuras/Index.h"
#include "../Estructuras/key_node.h"
#include "../Estructuras/ref.h"
#include "../Estructuras/refs.h"
#include "../Estructuras/TableIndex.h"
*/
#endif /* ESTRUCTURAS_H_ */
