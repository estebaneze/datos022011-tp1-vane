/*
 * OperationNotFoundException.cpp
 *
 *  Created on: Apr 29, 2010
 *      Author: carlos
 */

#include "OperationNotFoundException.h"

OperationNotFoundException::OperationNotFoundException() throw(){

}

OperationNotFoundException::~OperationNotFoundException() throw(){

}
