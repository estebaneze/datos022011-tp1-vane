#include "OperationNotFoundException.h"

OperationNotFoundException::OperationNotFoundException() throw(){

}

OperationNotFoundException::~OperationNotFoundException() throw(){

}
