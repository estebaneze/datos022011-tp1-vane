#include "ComposedBalanceStrategy.h"

ComposedBalanceStrategy::ComposedBalanceStrategy() {
}

ComposedBalanceStrategy::~ComposedBalanceStrategy() {
}
