#include "BalanceStrategy.h"
#include "../BPlusTree/Node.h"
#include "../BPlusTree/LeafNode.h"
BalanceStrategy::BalanceStrategy() {

}

BalanceStrategy::~BalanceStrategy() {
}
