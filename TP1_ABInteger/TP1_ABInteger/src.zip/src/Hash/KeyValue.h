/*
 * KeyValue.h
 *
 *  Created on: 16/10/2011
 *      Author: minnie
 */

#ifndef KEYVALUE_H_
#define KEYVALUE_H_

#include <string>

using namespace std;

struct KeyValue{
	string Key;
	string Value;
};

#endif /* KEYVALUE_H_ */
