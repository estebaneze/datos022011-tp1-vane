/*
 * HashExceptions.cpp
 *
 *  Created on: 14/10/2011
 *      Author: gabriel
 */

#include "HashExceptions.h"

