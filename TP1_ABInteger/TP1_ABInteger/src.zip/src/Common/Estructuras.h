/*
 * Estructuras.h
 *
 *  Created on: 27/09/2011
 *      Author: minnie
 */

#ifndef ESTRUCTURAS_H_
#define ESTRUCTURAS_H_

#include "../Estructuras/HashExtensible.h"
#include "../Estructuras/bp_tree.h"
#endif /* ESTRUCTURAS_H_ */
