/*
 * Common.h
 *
 *  Created on: 25/09/2011
 *      Author: minnie
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <time.h>
#include <cstdlib>

#include "Identities.h"
#include "../Logging/Log.h"
#include "../utils/ConfigurationMananger.h"
#include "Helper.h"

using namespace std;

#endif /* COMMON_H_ */

